<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('user', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('pseudo');
            $table->bigInteger('email');
            $table->bigInteger('created_at');
            $table->bigInteger('end_at');
            $table->bigInteger('role');
            $table->bigInteger('teams_id');
            $table->foreign('teams_id')->references('id')->on('team');
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user');
    }
};
